export interface MatchOdds {
  home_win: number;
  draw: number;
  away_win: number;
}

export interface PredictionResult {
  home_win_probability: number;
  draw_probability: number;
  away_win_probability: number;
  most_likely_outcome: 'HOME_WIN' | 'DRAW' | 'AWAY_WIN';
}

import Groq from 'groq-sdk';

export class OddAnalysisEngine {
  private static groq: Groq | null = null;

  private static getGroqClient() {
    if (!this.groq) {
      const apiKey = process.env.GROQ_API_KEY;
      if (!apiKey) {
        throw new Error('GROQ_API_KEY is not defined in environment variables');
      }
      this.groq = new Groq({ apiKey });
    }
    return this.groq;
  }

  public static async analyze(odds: MatchOdds, matchName: string): Promise<PredictionResult> {
    const groq = this.getGroqClient();

    const prompt = `
      Analyze this football match: "${matchName}".
      The betting odds are:
      - Home Win: ${odds.home_win}
      - Draw: ${odds.draw}
      - Away Win: ${odds.away_win}

      Based on these odds and general football knowledge, provide a prediction.
      You MUST return a valid JSON object strictly adhering to this schema:
      {
        "home_win_probability": number (0-1 range, e.g. 0.455),
        "draw_probability": number (0-1 range, e.g. 0.250),
        "away_win_probability": number (0-1 range, e.g. 0.295),
        "most_likely_outcome": "HOME_WIN" | "DRAW" | "AWAY_WIN"
      }
      Do not include any markdown formatting like \`\`\`json. Return only the raw JSON string.
    `;

    try {
      const completion = await groq.chat.completions.create({
        messages: [{ role: 'user', content: prompt }],
        model: 'llama-3.3-70b-versatile',
        temperature: 0.1,
        response_format: { type: "json_object" },
      });

      const content = completion.choices[0]?.message?.content?.trim();

      if (!content) {
        throw new Error('Empty response from Groq');
      }

      // Clean up markdown code blocks if present (just in case)
      const cleanedContent = content.replace(/^```json\s*/, '').replace(/\s*```$/, '');

      return JSON.parse(cleanedContent) as PredictionResult;
    } catch (error) {
      console.error('Groq Analysis Failed:', error);
      // Fallback to simple math if API fails, or re-throw. 
      // For now, let's just return a placeholder or re-throw to be visible.
      // Re-implementing basic fallback to ensure the app doesn't crash completely.
      const p_home = 1 / odds.home_win;
      const p_draw = 1 / odds.draw;
      const p_away = 1 / odds.away_win;
      const total = p_home + p_draw + p_away;

      const round = (num: number) => parseFloat(num.toFixed(4));

      return {
        home_win_probability: round(p_home / total),
        draw_probability: round(p_draw / total),
        away_win_probability: round(p_away / total),
        most_likely_outcome: p_home > p_away && p_home > p_draw ? 'HOME_WIN' : (p_away > p_home && p_away > p_draw ? 'AWAY_WIN' : 'DRAW')
      };
    }
  }
}

// cd /Users/ajinkya/Desktop/Automation
// npx ts-node src/index.ts