import axios from 'axios';
import * as dotenv from 'dotenv';
import { OddAnalysisEngine, MatchOdds } from './engine';

dotenv.config();

const API_TOKEN = process.env.SPORTMONKS_API_TOKEN;

if (!API_TOKEN) {
    console.error('Error: SPORTMONKS_API_TOKEN not found in .env file');
    process.exit(1);
}

// Configuration
const CONFIG = {
    // Leagues available in the 'Football Free Plan' as discovered via API
    LEAGUE_IDS: [501, 271
        ], // 501: Premiership (Scotland), 271: Superliga (Denmark)
    DAYS_LOOKAHEAD: 30, // How many days into the future to look for fixtures
    MARKET_ID: 1, // Standard Sportmonks ID for "3Way Result" (Match Winner)
};

interface Fixture {
    id: number;
    name: string;
    starting_at: string;
    participants: {
        id: number;
        name: string;
        image_path: string;
        meta: { location: 'home' | 'away' };
    }[];
}

async function getFixtures() {
    try {
        const today = new Date();
        const future = new Date();
        future.setDate(today.getDate() + CONFIG.DAYS_LOOKAHEAD);

        // Format dates as YYYY-MM-DD
        const startStr = today.toISOString().split('T')[0];
        const endStr = future.toISOString().split('T')[0];

        // Build key arguments
        const leagueFilters = CONFIG.LEAGUE_IDS.join(',');

        const url = `https://api.sportmonks.com/v3/football/fixtures/between/${startStr}/${endStr}`;
        console.log(`Requesting fixtures between ${startStr} and ${endStr}`);
        console.log(`Filter Leagues: ${leagueFilters}`);

        const response = await axios.get(url, {
            params: {
                api_token: API_TOKEN,
                filters: `fixtureLeagues:${leagueFilters}`,
                include: 'participants;scores',
                per_page: 50,
            },
        });

        const data = response.data.data;

        if (!data || data.length === 0) {
            console.log('No upcoming fixtures found in the configured date range and leagues.');
            return [];
        }

        return data as Fixture[];
    } catch (error: any) {
        if (axios.isAxiosError(error)) {
            console.error(`API Error fetching fixtures: ${error.message} (Status: ${error.response?.status})`);
        } else {
            console.error('Error fetching fixtures:', error);
        }
        return [];
    }
}

async function getMatchOdds(fixtureId: number): Promise<MatchOdds | null> {
    try {
        const url = `https://api.sportmonks.com/v3/football/odds/pre-match/fixtures/${fixtureId}/markets/${CONFIG.MARKET_ID}`;
        const response = await axios.get(url, {
            params: { api_token: API_TOKEN },
        });

        const oddsData = response.data.data;

        // Handle various response shapes (array vs object)
        let oddsList: any[] = [];
        if (Array.isArray(oddsData)) {
            oddsList = oddsData;
        } else if (oddsData) {
            oddsList = [oddsData];
        }

        if (oddsList.length === 0) {
            return null;
        }

        let home_win = 0;
        let draw = 0;
        let away_win = 0;

        // Robustly search for 1x2 odds in the returned data
        for (const odd of oddsList) {
            // Some endpoints return 'label' directly on the object, others nested.
            // Based on previous output, it's flat: { label: "Home", value: "2.80", ... }

            const label = odd.label ? odd.label.toString().toLowerCase() : '';
            const value = parseFloat(odd.value);

            if (isNaN(value)) continue;

            // Match standard 1x2 labels
            if ((label === '1' || label === 'home') && !home_win) home_win = value;
            if ((label === 'x' || label === 'draw') && !draw) draw = value;
            if ((label === '2' || label === 'away') && !away_win) away_win = value;

            // Once we have all three, we can stop
            if (home_win && draw && away_win) break;
        }

        if (home_win && draw && away_win) {
            return { home_win, draw, away_win };
        }

        return null;

    } catch (error: any) {
        // Suppress logs for missing odds as it's common for far-future games
        // console.error(`Error fetching odds for fixture ${fixtureId}:`, error.message);
        return null;
    }
}

import * as fs from 'fs';
import * as path from 'path';

async function main() {
    console.log('--- Starting Deterministic Football Odds Analysis ---');
    console.log('Configuration:');
    console.log(`- Leagues: ${CONFIG.LEAGUE_IDS.join(', ')}`);
    console.log(`- Lookahead: ${CONFIG.DAYS_LOOKAHEAD} days`);

    const fixtures = await getFixtures();

    if (!fixtures || fixtures.length === 0) {
        return;
    }

    console.log(`Found ${fixtures.length} fixtures. Analyzing...`);

    // CSV Setup
    const csvFilename = path.join(__dirname, '..', 'predictions.csv');
    const csvHeaders = [
        'Fixture ID',
        'Date',
        'Match',
        'Home Odd',
        'Draw Odd',
        'Away Odd',
        'Home Win Prob',
        'Draw Prob',
        'Away Win Prob',
        'Prediction'
    ].join(',');

    fs.writeFileSync(csvFilename, csvHeaders + '\n');
    console.log(`Created CSV file: ${csvFilename}`);

    let count = 0;
    for (const fixture of fixtures) {
        const homeTeam = fixture.participants.find(p => p.meta.location === 'home');
        const awayTeam = fixture.participants.find(p => p.meta.location === 'away');

        if (!homeTeam || !awayTeam) continue;

        const odds = await getMatchOdds(fixture.id);

        if (odds) {
            count++;
            const matchName = `${homeTeam.name} vs ${awayTeam.name}`;
            const prediction = await OddAnalysisEngine.analyze(odds, matchName);

            const output = {
                fixture_id: fixture.id,
                fixture_date: fixture.starting_at,
                match: matchName,
                odds: odds,
                analysis: prediction
            };

            // Console Output
            console.log('------------------------------------------------');
            console.log(JSON.stringify(output, null, 2));

            // CSV Output
            const csvRow = [
                output.fixture_id,
                output.fixture_date,
                `"${output.match}"`, // Quote match name to handle potential commas
                output.odds.home_win,
                output.odds.draw,
                output.odds.away_win,
                output.analysis.home_win_probability,
                output.analysis.draw_probability,
                output.analysis.away_win_probability,
                output.analysis.most_likely_outcome
            ].join(',');

            fs.appendFileSync(csvFilename, csvRow + '\n');
        }
    }

    if (count === 0) {
        console.log('No odds available for any of the fetched fixtures.');
    } else {
        console.log('------------------------------------------------');
        console.log(`Analysis complete. Results saved to ${csvFilename}`);
    }
}

main();