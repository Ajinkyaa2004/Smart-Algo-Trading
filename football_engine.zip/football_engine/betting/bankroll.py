import pandas as pd, numpy as np
from .kelly import kelly_fraction
from .odds_utils import decimal_odds_from_row_for_outcome
from models.predict_models import update_model_probabilities

def backtest_block(df,providers,models,cfg):
    bank=cfg['start_bank']; hist=[]
    for i,r in df.iterrows():
        if r['Match_Type']=='Not Classified': continue
        p=update_model_probabilities(r,models)
        pred=max(p,key=p.get); prob=p[pred]
        od=decimal_odds_from_row_for_outcome(r,pred,providers)
        if not np.isfinite(od): continue
        k=kelly_fraction(prob,od)
        if k<=0: continue
        stake=bank*k*cfg['fractional_kelly']*cfg['risk_multiplier']
        if stake<cfg['min_bet']: continue
        actual=r.get('FTR')
        if not isinstance(actual,str): continue
        if pred==actual: bank+=stake*(od-1)
        else: bank-=stake
        hist.append({'pred':pred,'actual':actual,'stake':stake,'odds':od,'bank':bank})
    dfh=pd.DataFrame(hist)
    dfh = pd.DataFrame(hist)

    total_bets = len(dfh)
    wins = (dfh['pred'] == dfh['actual']).sum()
    win_rate = wins / total_bets if total_bets > 0 else 0
    roi = (bank - cfg['start_bank']) / cfg['start_bank']
    
    return dfh,roi,total_bets,wins,win_rate