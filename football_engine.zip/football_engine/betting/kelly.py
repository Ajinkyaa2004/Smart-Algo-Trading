def kelly_fraction(p,od):
    if od<=1 or p<=0: return 0
    return max(0,(p*od-1)/(od-1))