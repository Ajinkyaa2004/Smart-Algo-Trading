import numpy as np
def decimal_odds_from_row_for_outcome(row, outcome, providers):
    col=providers[0]+outcome
    v=row.get(col,np.nan)
    try: v=float(v)
    except: return np.nan
    return v if v>1 else np.nan