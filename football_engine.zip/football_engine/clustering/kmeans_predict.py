def assign_cluster_labels(kmeans, df):
    df=df.copy()
    feats=['Draw_Prob','Fav_Gap','Market_Imbalance']
    m=df[feats].notna().all(axis=1)
    df['Match_Type']='Not Classified'
    if kmeans is None: return df
    df.loc[m,'Cluster']=kmeans.predict(df.loc[m,feats])
    means=df.loc[m].groupby('Cluster')['Fav_Gap'].mean()
    hi=int(means.idxmax()); lo=1-hi
    df.loc[m,'Match_Type']=df.loc[m,'Cluster'].map({hi:'High_Scoring',lo:'Defensive'})
    return df