from sklearn.cluster import KMeans
def train_kmeans(df):
    X=df[['Draw_Prob','Fav_Gap','Market_Imbalance']].dropna()
    if len(X)<10: return None
    k=KMeans(n_clusters=2,random_state=42,n_init=10).fit(X)
    return k