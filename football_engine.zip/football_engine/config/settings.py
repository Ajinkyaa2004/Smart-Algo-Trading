PROVIDERS=['B365']
PATHS={
 'history_file':'First train data.xlsx',
 'predictions_out':'test_pred2.xlsx',
 'validated_out':'Validate2.xlsx',
 'models_store':'models.pkl',
 'cluster_store':'kmeans.pkl',
 'combined_training':'combined_training.xlsx'
}
CFG={'start_bank':10000,'fractional_kelly':0.15,'risk_multiplier':2.0,'min_bet':1,'max_bet_pct':0.3}