import pandas as pd, numpy as np
def calculate_consensus_probabilities(df, providers):
    df=df.copy()
    pH=1/df[providers[0]+'H']; pD=1/df[providers[0]+'D']; pA=1/df[providers[0]+'A']
    s=pH+pD+pA
    df['Prob_Home']=pH/s; df['Prob_Draw']=pD/s; df['Prob_Away']=pA/s
    return df
def create_openness_signals(df):
    df=df.copy()
    df['Draw_Prob']=df['Prob_Draw']
    df['Fav_Gap']=df[['Prob_Home','Prob_Away']].max(axis=1)-df['Prob_Draw']
    def imb(r):
        x=[r['Prob_Home'],r['Prob_Draw'],r['Prob_Away']]
        if any(pd.isna(x)): return np.nan
        x=sorted(x,reverse=True); return x[0]-x[1]
    m=df[['Prob_Home','Prob_Draw','Prob_Away']].notna().all(axis=1)
    df.loc[m,'Market_Imbalance']=df.loc[m].apply(imb,axis=1)
    return df