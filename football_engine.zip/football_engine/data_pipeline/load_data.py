import pandas as pd
def load_data(path):
    if path.lower().endswith("csv") :
        df=pd.read_csv(path)
    else:
        df=pd.read_excel(path)
    if 'Date' in df: df['Date']=pd.to_datetime(df['Date'],dayfirst=True,errors='coerce')
    for c in ['FTHG','FTAG']:
        if c in df: df[c]=pd.to_numeric(df[c],errors='coerce').fillna(0).astype(int)
    return df