import pandas as pd, numpy as np
def create_openness_signals(df):
    df=df.copy()
    df['Draw_Prob']=df['Prob_Draw']
    df['Fav_Gap']=df[['Prob_Home','Prob_Away']].max(axis=1)-df['Prob_Draw']
    def imb(r):
        x=[r['Prob_Home'],r['Prob_Draw'],r['Prob_Away']]
        if any(pd.isna(x)): return np.nan
        x=sorted(x,reverse=True); return x[0]-x[1]
    m=df[['Prob_Home','Prob_Draw','Prob_Away']].notna().all(axis=1)
    df.loc[m,'Market_Imbalance']=df.loc[m].apply(imb,axis=1)
    return df