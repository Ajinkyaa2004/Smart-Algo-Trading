def accuracy(df):
    return (df['pred']==df['actual']).mean()