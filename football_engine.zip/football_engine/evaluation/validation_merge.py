import pandas as pd
def merge_pred_actual(pred, actual):
    pred['Date']   = pd.to_datetime(pred['Date']).dt.date
    actual['Date'] = pd.to_datetime(actual['Date']).dt.date

    return pred.merge(actual[['Incremental_ID','FTR','Date']],on=['Incremental_ID','Date'],how='left')

