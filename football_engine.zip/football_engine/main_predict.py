from config.settings import PROVIDERS,PATHS
from data_pipeline.load_data import load_data
from data_pipeline.calculate_probabilities import calculate_consensus_probabilities
from data_pipeline.openness_signals import create_openness_signals
from clustering.kmeans_predict import assign_cluster_labels
from models.save_load_models import load_models
from models.predict_models import update_model_probabilities
import joblib, pandas as pd
pred_file='test2.xlsx'
def run(pred_file):
    models=load_models(PATHS['models_store'])
    km=joblib.load(PATHS['cluster_store'])
    df=load_data(pred_file)
    df=calculate_consensus_probabilities(df,PROVIDERS)
    df=create_openness_signals(df)
    df=assign_cluster_labels(km,df)
    out=[]
    for _,r in df.iterrows():
        p=update_model_probabilities(r,models)
        pred=max(p,key=p.get)
        out.append({'predicted':pred,'probs':p})
    outdf=pd.concat([df.reset_index(drop=True),
                     pd.DataFrame(out)],axis=1)
    outdf.to_excel(PATHS['predictions_out'],index=False)
    return outdf
run(pred_file)
