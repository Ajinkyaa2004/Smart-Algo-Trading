from config.settings import PROVIDERS,PATHS
from data_pipeline.load_data import load_data
from data_pipeline.calculate_probabilities import calculate_consensus_probabilities
from data_pipeline.openness_signals import create_openness_signals
from clustering.kmeans_train import train_kmeans
from clustering.kmeans_predict import assign_cluster_labels
from models.train_models import train_poisson,train_bernoulli
from models.save_load_models import save_models
import joblib

df=load_data(PATHS['history_file'])
df=calculate_consensus_probabilities(df,PROVIDERS)
df=create_openness_signals(df)
km=train_kmeans(df)
df=assign_cluster_labels(km,df)
p=train_poisson(df); b=train_bernoulli(df)
models={}
if p: models['poisson']=p
if b: models['bernoulli']=b
save_models(models,PATHS['models_store'])
joblib.dump(km,PATHS['cluster_store'])
print("Training completed.")