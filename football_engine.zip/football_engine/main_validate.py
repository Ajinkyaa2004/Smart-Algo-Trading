from config.settings import PATHS,PROVIDERS,CFG
import pandas as pd
from evaluation.validation_merge import merge_pred_actual
from betting.bankroll import backtest_block
from models.save_load_models import load_models

pred=pd.read_excel(PATHS['predictions_out'])
actual=pd.read_excel(PATHS['validated_out'])
merged=merge_pred_actual(pred,actual)
models=load_models(PATHS['models_store'])
hist,roi,total_bets,wins,win_rate=backtest_block(merged,PROVIDERS,models,CFG)
def merge_train_test():
    # Load both files
    history_df   = pd.read_excel(PATHS['history_file'])
    validated_df = pd.read_excel(PATHS['validated_out'])

    # Append new validated rows into history
    merged_df = pd.concat([history_df, validated_df], ignore_index=True)

    # Overwrite history file with merged data
    merged_df.to_excel(PATHS['history_file'], index=False)
    merged_df.drop_duplicates(['Incremental_ID','Date'], inplace=True)
    return merged_df
updated_data=merge_train_test()
print("Wins:",wins)
print("Winrate:",win_rate)
# print("Accuracy:",(len(hist)/len(pred))*100)
print("ROI:",roi*100)
print("Bets placed:",total_bets)
print("Total matches:",len(pred))
