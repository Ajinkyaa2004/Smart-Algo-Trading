import pandas as pd, numpy as np
def update_model_probabilities(row, models):
    p={'H':row['Prob_Home'],'D':row['Prob_Draw'],'A':row['Prob_Away']}
    if any(pd.isna(v) for v in p.values()): return p
    mt=row.get('Match_Type','')
    if mt=='High_Scoring' and models.get('poisson'):
        model,feats=models['poisson']
        X=[1]+[row[f] for f in feats if f!='const']
        lam=np.exp(model.predict(pd.DataFrame([X],columns=feats))[0])
        red=min(0.10,(lam-2)/4 if lam>2 else 0)
        p['D']*=1-red
        s=p['H']+p['A']
        p['H']=p['H']/s*(1-p['D']); p['A']=p['A']/s*(1-p['D'])
    if mt=='Defensive' and models.get('bernoulli'):
        model,feats=models['bernoulli']
        X=pd.DataFrame([[row[f] for f in feats]],columns=feats)
        pH=model.predict_proba(X)[0][1]
        p['H']=pH; p['A']=1-p['H']-p['D']
    # normalize
    s=sum(p.values())
    return {k:p[k]/s for k in p}