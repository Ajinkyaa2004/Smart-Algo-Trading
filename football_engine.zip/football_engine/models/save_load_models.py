import joblib
def save_models(m,path): joblib.dump(m,path)
def load_models(path): return joblib.load(path)