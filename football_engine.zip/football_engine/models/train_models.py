import statsmodels.api as sm
from sklearn.linear_model import LogisticRegression

def train_poisson(df):
    hs=df[df['Match_Type']=='High_Scoring'][['FTHG','FTAG','Prob_Home','Prob_Away','Prob_Draw']].dropna()
    if len(hs)<50: return None
    X=sm.add_constant(hs[['Prob_Home','Prob_Away','Prob_Draw']]); y=hs['FTHG']+hs['FTAG']
    m=sm.GLM(y,X,family=sm.families.Poisson()).fit()
    return (m,X.columns.tolist())

def train_bernoulli(df):
    d=df[df['Match_Type']=='Defensive'][['FTR','Prob_Home','Prob_Away','Prob_Draw']].dropna()
    if len(d)<50: return None
    d['HWIN']=(d['FTR']=='H').astype(int)
    X=d[['Prob_Home','Prob_Away','Prob_Draw']]; y=d['HWIN']
    lr=LogisticRegression(solver='liblinear').fit(X,y)
    return (lr,X.columns.tolist())